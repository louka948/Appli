# Tester "L'Insider" sur iPhone — guide pour toi

Merci de filer un coup de main pour tester l'appli sur un vrai iPhone ! Voici
la marche à suivre, étape par étape. Ça prend une vingtaine de minutes la
première fois, et ça ne demande aucune connaissance en programmation.

## Ce qu'il te faut

- Un **Mac** avec **Xcode** installé (gratuit, via l'App Store — cherche
  "Xcode", c'est un gros téléchargement, prévois du temps/du wifi correct
  s'il n'est pas déjà installé).
- Un **iPhone** + son câble (ou le même réseau wifi que le Mac pour une
  connexion sans fil, mais le câble est plus simple pour une première fois).
- Un **Apple ID** (le tien, celui que tu utilises normalement sur ton
  iPhone/Mac — pas besoin de compte développeur payant pour ce test).

## Étape 1 — Ouvrir le projet dans Xcode

1. Dézippe ce fichier si ce n'est pas déjà fait.
2. Dans le dossier obtenu, va dans `ios/App/` et double-clique sur
   **`App.xcodeproj`**. Ça ouvre Xcode.
3. Xcode va automatiquement télécharger/résoudre quelques dépendances
   ("Resolving Package Graph" en bas de la fenêtre) — laisse-le faire,
   ça prend une minute ou deux la première fois (connexion internet
   nécessaire à ce moment-là).

## Étape 2 — Brancher ton iPhone

1. Branche l'iPhone au Mac avec le câble.
2. Sur l'iPhone, si une popup "Faire confiance à cet ordinateur ?"
   apparaît, accepte et entre ton code.
3. Dans Xcode, en haut de la fenêtre, il y a un menu déroulant avec le
   nom d'un simulateur (genre "iPhone 15 Pro"). Clique dessus et
   sélectionne **ton iPhone** dans la liste (il doit apparaître une fois
   branché et déverrouillé).

## Étape 3 — Signer l'app avec ton Apple ID (obligatoire, gratuit)

1. Dans le panneau de gauche, clique sur **"App"** (l'icône bleue tout en
   haut), puis dans l'onglet **"Signing & Capabilities"**.
2. Coche **"Automatically manage signing"** si ce n'est pas déjà fait.
3. Dans le menu **"Team"**, sélectionne ton Apple ID. S'il n'apparaît pas :
   va dans **Xcode → Settings → Accounts**, clique sur **"+"** et connecte-toi
   avec ton Apple ID (le même que sur ton iPhone), puis reviens à l'étape
   précédente.
4. Xcode va générer automatiquement un certificat de test gratuit — pas
   besoin d'un compte développeur payant pour ça.

## Étape 4 — Lancer l'app

1. Clique sur le bouton **▶ (Play)** en haut à gauche de Xcode.
2. Xcode installe l'app sur ton iPhone. La première fois, l'iPhone va
   probablement refuser de la lancer et afficher un message du genre
   *"Développeur non fiable"*. C'est normal, il faut l'autoriser une
   fois :
   - Sur l'iPhone : **Réglages → Général → VPN et gestion de l'appareil**
   - Trouve ton Apple ID sous "App développeur", tape dessus, puis
     **"Faire confiance à [ton nom]"**.
3. Retourne sur l'écran d'accueil, l'app **"L'Insider"** devrait avoir une
   icône — lance-la normalement.

## À savoir

- Cette installation "gratuite" (sans compte développeur payant) **expire
  au bout de 7 jours** — passé ce délai, il faudra rebrancher l'iPhone et
  refaire l'étape 4 (juste re-cliquer sur ▶) pour continuer à tester. Pas
  besoin de refaire tout le reste.
- Si tu changes d'iPhone ou que tu recommences après un moment, il se peut
  que Xcode redemande de sélectionner l'appareil (étape 2) — rien
  d'inquiétant.
- Si un message d'erreur bloque quelque part, fais une capture d'écran et
  envoie-la, ce sera plus simple à débloquer avec ça sous les yeux.

Merci encore pour le coup de main !
